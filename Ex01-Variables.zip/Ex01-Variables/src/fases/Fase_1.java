package fases;

public class Fase_1 {

	public static void main(String args[]) {
		
		String nom;
		String cognoms1;
		String cognoms2;
		
		int dia;
		int mes;
		int any;
		
		nom = "Jordi";
		cognoms1 = "Miret";
		cognoms2 = "Mass�";
		
		dia = 23;
		mes = 4;
		any = 2020;
		
		System.out.println(cognoms1 + " " + cognoms2 + " " + nom);
		System.out.println(dia + "/" + mes + "/" + any);
		
	}
}
